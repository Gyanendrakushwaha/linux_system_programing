#include<stdio.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>

#define BUF_LEN 256

void toggleCase(char *buf,int cnt);

int main()
{
	int cliFD,srvFD,cnt=0;
	char buf[BUF_LEN];
	while(1)
	{
		printf("Waiting for connecting to client\n");
		srvFD = open("srvfifo",O_RDONLY);
		if(srvFD < 0){
			if(mkfifo("srvfifo", 0600)<0){
				printf("Error is creating FIFO\n");
				return 1;
			}else{
				printf("Created a FIFO\n");
				srvFD = open("srvfifo", O_RDONLY);
			}
		}
		printf("Connected to client through FIFO\n");	
		while(1)
		{
			cnt = read(srvFD,buf,BUF_LEN);
			if(cnt ==0)
				break;
			printf("Received Mesage\n");
			toggleCase(buf,cnt);
			cliFD = open("clififo",O_WRONLY);
			if(cliFD){
				printf("Sent response message\n");
				write(cliFD,buf,cnt);
				close(cliFD);
			}else{
				printf("CLoud not open client fifo\n");	
			}
		}
		close(srvFD);
	}
}
void toggleCase(char *buf, int cnt)
{
	int ii;	
	for(ii=0;ii<cnt;ii++)
	{
		if((buf[ii] >= 'A') && (buf[ii] <= 'Z')){	
			buf[ii] += 0x20;
		}
		else if((buf[ii] >= 'a') && (buf[ii] <= 'z')){
			buf[ii] -= 0x20;
		}
	}
}

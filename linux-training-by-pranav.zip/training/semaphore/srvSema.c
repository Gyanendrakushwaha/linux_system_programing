#include<stdio.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<sys/shm.h>
#include<string.h>

#define MY_KEY 1992
#define SHM_SIZE 0x1000

int main()
{
	int semID,shmID;
	char *pShm;
	struct sembuf smop;

	/* Create a semaphore sey, containing two semaphore */
	semID = semget(MY_KEY, 1, 0660|IPC_CREAT);
	if(semID<0)
	{	
		printf("Could not reate semaphore\n");
		return(1);
	}
	else{
		printf("Opened a semaphore ID is %d\n",semID);
	}

/*set initial token count od both semaphore to zeros*/
	semctl(semID, 0, SETVAL, 0);
	//semctl(semID,1,SETVAL,0);
	
	/*Create a shared memor segment*/
	shmID = shmget(MY_KEY, SHM_SIZE, 0660|IPC_CREAT);
	if(shmID<0)
	{		
		printf("Could not create shared segment\n");
		return (2);
	}

	/*Attach shared memory segment to process address space*/
	pShm = shmat(shmID,NULL,0);
	if(!pShm)
	{	
		printf("Could not attach shareed memory segment\n");
		return(3);
	}

	/*wait for token from semaphore 0*/
	smop.sem_num = 0;
	smop.sem_op = -1;
	smop.sem_flg = 0;
	
	semop(semID, &smop, 1); //server is blocked on semaphore
													//once cli ecext semop (inc cmtr by 1)
												//server gets unblocked.......
		/** Process the messagre available in shared memory ****/
	printf("Got the Semaphore\n");
	printf("%s\n",pShm);
}

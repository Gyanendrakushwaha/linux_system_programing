#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include<sys/ipc.h>
#include<sys/sem.h>

int get_semaphore(void);
int release_semaphore(void);
int sem_id;

struct sembuf sem_op; //refer man page

int main()
{
	int i;
	sem_id = semget((key_t)1234,1,0666|IPC_CREAT);

/* parm1: 1234-semaphore key that can be used by other process to share the same semaphore
	parm2:(1_:No of semaphore i.e. if u have more than one resorces that has to be synchronized u can give a value other than one here
	*parm3: flags that gives perms and to create a semaphore with those perms */

//sem)union,val=1
if(semctl(sem_id,0,SETVAL,1)<0) /* semaphore initialization -- id, semnum,cmd,obj to sem_union*/
	printf("error\n");
for(i = 0;i<=5;i++)
{
	get_semaphore();
	printf("%d: got the semaphore\n",getpid());
	sleep(1);
	printf("%d: realeased to delete the semaphore\n",getpid());
	release_semaphore();
}
if(semctl(sem_id,0,IPC_RMID,0)<0)
	printf("Failed to delete the semaphore\n");
else
	printf("semaphore deleted\n");

}

int get_semaphore(void)
{
	sem_op.sem_num = 0;
	// gets the nth no of semaphore specified in sem_num, herer its zero, i.e the zeroth semaphore in the semaphore array
	sem_op.sem_op	= -1;
	/*decrement the nth semaphore bu one,
	the 'n' value is speciied by the vairaible sem_num in sembuf structure,
	here the n value is zero (refer the previous statment) */

	//sem_op.sem_flg = sem_UNDO;
	sem_op.sem_flg = 0;
	
	//this flag us optional but ist wise to set this flag
	//it tells the kernal to automatically release the semaphore
	// if this process terminates without releasing the semaphore...
	//itcan also have tthe falg IPC_NOWAIT(refer man)
	if(semop(sem_id, &sem_op,1)<0)
	{
		printf("Failed to get the semaphore\n");
		return -1;
	}
	/* param 1:Semaphore_id returned by semget system call
	* param 2: pointer to sem_buf structure(refer man)
	* param 3: no of semaphpre operations structures since we are isning only one semaphore we have the value 1 here */
	return 0;
}

int release_semaphore(void)
{
	sem_op.sem_num = 0;
	sem_op.sem_op = 1;// same as above but here insted of icrementing we are decrementing the semaphore to release it
	//sem_op.sem_flg = SEM_UNDO
	sem_op.sem_flg = 0;
	if(semop(sem_id, &sem_op,1)<0)
	{
		printf("Failed to release semaphore\n");
		return 0;
	}
}

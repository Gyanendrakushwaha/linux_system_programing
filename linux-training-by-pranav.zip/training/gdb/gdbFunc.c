#include<stdio.h>

void myprint(char *msg){
	if(msg != NULL){
		printf("msg: %s\n",msg);
	}
}

void main(){
	char buff[] = "linux";
	myprint(buff);
}

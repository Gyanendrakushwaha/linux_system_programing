#include<stdio.h>

void main(){
	int i;
	int x[] = {12,22,33,44};
	
	for(i=0;i<4;i++){
		printf("Value of x = %d\n",x[i]);
	}
}

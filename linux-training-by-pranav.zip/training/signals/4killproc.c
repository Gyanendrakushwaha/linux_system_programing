#include<stdio.h>
#include<unistd.h>
#include<signal.h>

int main()
{
	pid_t pid;
	int sig_no;
	printf("Enter the pid of the process for which the signal need to ve sent:");
	scanf("%d",&pid);
	printf("Enter the sognal that need to be sent:");
	scanf("%d",&sig_no);
	kill(pid, sig_no);
	perror("Sig_res:");
}

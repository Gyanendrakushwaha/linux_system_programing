#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<signal.h>
/* sig hand for one*/

void sh_for_one(int signum)
{
	printf("This is handler for signal no one \n");
}
	
/* below is the handler for signals */
void sh_for_nine(int signum)
{
	printf("I am now handling signal no %d\n", signum);
}

int main()
{
	/* install signal handler for 1,2 and 3 */
	signal(1,sh_for_one);
	signal(9,sh_for_nine);
	perror("Siginstall: ");
	getchar();
	getchar();
/* use macroiws insted of constansts as signal numbers to imprive redability */
	while(1){
	sleep(1);
		printf("I am happy now , i will do same work forever: %d\n",getpid());
	}
}

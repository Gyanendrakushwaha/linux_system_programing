/* Shows an example od when sigabort woll ve geneatwd
Versopm: 1.0
Aurthor :Team -C
*/

#include<stdio.h>
#include<unistd.h>
#include<signal.h>
#include<stdlib.h>
void sighand(int sig_num)
{
	printf("abort signal red'd\n");
	printf("We can use this to perform clean up op's\n");
}

int main()
{
//	signal(SIGABRT, sighand);
	printf("Some thing has gone wrong\n");	
	abort();
	printf("Can you see this\n");
	printf("Can you see this\n");
	printf("Can you see this\n");
}

#include<stdio.h>
#include<signal.h>

void sighandler(int sigNo){	
	printf("Signal handler function displying Signo: %d\n",sigNo);
	//signal(SIGINT,SIG_DFL);//This will get default action
}

int main()
{
	struct sigaction act;
	act.sa_handler = sighandler;
	act.sa_flags = 0; //specifies set og falgs which modify the behavior of the signal
	sigemptyset(&act.sa_mask); //sepcifies ast od sinals which should be blocked dutring execution of signal handler
	sigaction(SIGINT,&act,0);
	//signal(sighandler,sig_DLF);
	while(1)
	{
		printf("Hello,World\n");
		sleep(1);
	}
}

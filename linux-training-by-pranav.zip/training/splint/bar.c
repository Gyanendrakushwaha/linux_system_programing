#include<stdio.h>

int main()
{
	int x = 111;
	int i;
	for(i=0;i<10;i++)
	{
		printf("i value= %d\n", i+1);
	}
return 0;
}

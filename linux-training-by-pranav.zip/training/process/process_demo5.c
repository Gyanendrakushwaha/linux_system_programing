#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
	void callback1(void)
	{
		printf("callback 1 func called\n");
	}
	
	void callback2(void)
	{
		printf("callback 2 func called\n");
	}
	void callback3(void)
	{
		printf("callback 3 func called\n");
	}
	
int main()
{	
	printf("registerning callback1\n");
	atexit(callback1);	

	printf("registerning callback2\n");
	atexit(callback2);	

	printf("registerning callback3\n");
	atexit(callback3);
	return 0;
	//exit(0);
}

	

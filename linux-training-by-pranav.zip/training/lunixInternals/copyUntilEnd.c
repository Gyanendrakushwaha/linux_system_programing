#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#define BUF_SIZE 1024

int main()
{
	int inputFd,outputFd,openFlags;
	mode_t filePerms;
	ssize_t numRead;
	char buf[BUF_SIZE];

	inputFd = open("fileA.txt",O_RDONLY);
	if(inputFd == -1)
	{
		printf("Open Erro\n");
		return;
	}
	
	outputFd = open("fileB.txt",O_RDWR,777);
	if(outputFd == -1)
	{
		printf("Opening file\n");
		return;
	}
	//transfer
	while((numRead = read(inputFd, buf, BUF_SIZE)) > 0)
	{
		ssize_t n = write(outputFd,buf, numRead);
		if(n != numRead)
		{
			printf("Write Error\n");
			return;
		}
		printf("%d / %d\n",n,numRead);
	}
	if(numRead == -1)
	{
		printf("Read Error\n");
		return;
	}
	if(close(inputFd) == -1)
	{
		printf("Close input\n");
		return;
	}
	if((close(outputFd))== -1)
	{
		printf("Close output\n");
		return;
	}
}	

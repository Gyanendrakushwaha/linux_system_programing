#include<stdio.h>
#include"file.h"

void main(){
	int a = 10;
	int b = 20;
	printf("%d -%d = %d\n",b,a,sub(a,b));
	printf("%d + %d = %d\n",a,b,add(a,b));
	}

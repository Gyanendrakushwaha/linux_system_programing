
int sub(int,int);
int add(int,int);

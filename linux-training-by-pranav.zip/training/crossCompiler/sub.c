#include<stdio.h>
#include"file.h"

int sub(int a,int b){
	return b-a;
}


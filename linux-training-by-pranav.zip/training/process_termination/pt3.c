#include<stdio.h>
#include<sys/wait.h>
#include<stdlib.h>
#include<sys/types.h>
int main()
{
	pid_t chpid, child1, child2;
	int ii,stat;
	printf("I am a process my process id is %d\n",getpid());
	printf("I am creating two child process & make them run some code\n");

	child1 = fork();
	if(child1 ==0)
	{
		printf("I am first child, my pid is %d\n",getpid());
		printf("I am tried, sleeping for 10 seconds\n");
		exit(0);
	}
	child2 = fork();
	if(child2==0)
	{
		printf("I AM Secound child, my pid is %d\n",getpid());
		printf("I am tried, sleeping for 5 secound\n");
		exit(0);	
	}
	printf("I	am parent, my childern are working & sleeping, i wait for then\n");
	chpid = wait(&stat);
	if(chpid == child1)
	{
		printf("My first child terminated with status %d\n",WEXITSTATUS(stat));
	}
	if(chpid == child2)
	{
		printf("My Secound child terminated with status %d\n",WEXITSTATUS(stat));	
	}
	chpid = wait(&stat);	
	if(chpid == child1)
	{
		printf("My first child terminated with status %d\n",WEXITSTATUS(stat));
	}
	if(chpid == child2)
	{
		printf("My Secound child terminated with status %d\n",WEXITSTATUS(stat));	
	}
printf("Both childred got terminated, now i will do the same\n");
}

#include<stdio.h>
#include<sched.h>

int main()
{
		int policy;
		printf("my pidis %d\n",getpid());
		
		/* Get our scheduling policy */
		policy = sched_getscheduler(0); //return policy of calling process	
	
		switch(policy)
		{
			case SCHED_OTHER:
					printf("Policy is normal\n");
					break;
			case SCHED_RR:
					printf("Policy is round-robin\n");
					break;
			case SCHED_FIFO:
					printf("Policy i sfirst-in-first-out.\n");
					break;
			case -1:
					perror("shed_getscheduler");
					break;

			default:
					fprintf(stderr, "Unknown policy!\n");
		}

		getc(stdin); //wait
		/* set our scheduiing policy */
		struct sched_param sp ={.sched_priority=1}; //RR policy
		int ret;
							//(pid_t pid, int policy, struct sched_param *ptr)
		ret = sched_setscheduler(0,SCHED_RR, &sp); // sch policy and paramt of a calling
										//proxcess
		if(ret == -1){
				perror("sched_setscheduler");
				return 1;
		}

	/* get out scheduling policy */
	policy = sched_getscheduler(0);

		switch(policy)
		{
			case SCHED_OTHER:
					printf("Policy is normal\n");
					break;
			case SCHED_RR:
					printf("Policy is round-robin\n");
					break;
			case SCHED_FIFO:
					printf("Policy i sfirst-in-first-out.\n");
					break;
			case -1:
					perror("shed_getscheduler");
					break;

			default:
					fprintf(stderr, "Unknown policy!\n");
		}
		getc(stdin);
	while(1);
	return 0;
}	

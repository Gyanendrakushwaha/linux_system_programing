#include<stdio.h>
#include<string.h>

int main()
{	
	const char str[] = "linuxkernal.com";
	const char ch = '#';
	//char *ret;
	printf("String before set/initialization is %s \n",str);
	memset(str,ch,5);
	printf("String after ste os %s \n",str);
	return(0);
}

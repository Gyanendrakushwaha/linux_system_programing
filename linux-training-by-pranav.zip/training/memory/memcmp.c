#include<stdio.h>
#include<string.h>

int main()
{	
	char buff1[10];
	char buff2[10];
	int ret;
	
	memcpy(buff1, "LINUX", 5); 
	memcpy(buff2, "LINUX", 5); 

	ret = memcmp(buff1,buff2, 5);
	if(ret > 0)
		printf("buf1 is greater than buf2\n");
	else if(ret <0)
		printf("buff1 is less than buff2\n");
	else
		printf("buf1 is equal to buf2\n");

return 0;
}

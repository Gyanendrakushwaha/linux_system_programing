#include<stdio.h>
#include<string.h>

int main()
{	
	const char str[] = "linuxkernal.com";
	const char *ch = &str[0];
	//char *ret;
	printf("String before set/initialization is: %s \n",str);
	bzero(ch,5);
	printf("String after set os: %s \n",str);
	return(0);
}

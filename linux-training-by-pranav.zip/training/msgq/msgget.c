#include<stdio.h>
#include<string.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>

struct msgbuf{ 								// user defined structure to pack (data + type)
	long mtype;						//mtype is type
	char data[512];			 // data is to send to process
};

int main(int argc, char *argv[]){
	struct msgbuf v;
	int id;
	
	id = msgget(55,IPC_CREAT|0644);
	// create new msgq, if msg q with key 55 is not present
	// on success return msgID
	printf("id = %d\n",id); // display ID
	v.mtype=atoi(argv[1]); //"12" //argument 1 is type of msg converting ascii to int
	strcpy(v.data, argv[2]); // Argument 2 is msg
	msgsnd(id,&v,strlen(v.data)+1,0);
	return 0;
}

#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>

void main()
{	
	int qid;
	qid = msgget(55,IPC_CREAT|644);
	printf("qid = %d\n",qid);
	getchar();
	msgctl(qid,IPC_RMID,NULL);
}

//write a program that create meggage queue and display msgq id and remove the allocate msg queue from system

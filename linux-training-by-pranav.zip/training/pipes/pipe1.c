#include<stdio.h>
#include<unistd.h>
#include<string.h>

int main()
{
	int p[2]; // p[0],p[1] indexex of subscripts of array p
	pipe(p); //fd0 --P[0]rd end and fd1---P[1] wt end

	printf("Read end of pipe = %d\t Write end of pipe = %d\n",p[0], p[1]); //3, 4
	if(fork())
	{
		char s[20];
		printf("In Parent Enter Data...\n");
		scanf("%s",s); //wait user enter "15+1
		write(p[1], s, strlen(s)+1); //Parent send data on pipe....write(fd, buf, 20);
	}
	else{
		char buf[20];
		printf("In CHild...\n");
		read(p[0], buf, sizeof(buf)); // block.... Child collect data
		printf("child pro printing..Data. of the parent process..%s\n", buf);
	}

	return 0;
}

#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<string.h>

pthread_t tid;

//pthread_attr_t my attr;

void* thread1(void *arg){
	sleep(1);
	printf("Newly created Thread is executing\n");
	return NULL;
}

int main(void)
{	
	int ret = pthread_create(&tid, NULL,thread1,NULL); //addr of func...nameof fun
	if(ret)																						//NULL default attr
		printf("Thread is not created\n");
	else
		printf("Thread is created\n");
																				//sleep(2);//getchar();
		 pthread_join(tid,NULL);
return 0;
}

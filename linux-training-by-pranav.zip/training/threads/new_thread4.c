#include<pthread.h>
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/mman.h>

void* Proc(void *param)
{
	sleep(2);
	return 0;
}

int main()
{
	pthread_attr_t Attr; //1
	pthread_t ID;
	void *Stk;
	size_t Siz; //size_t int
	int err;

	size_t my_stksize = 0x300000;
	void *my_stack;
	
	pthread_attr_init(&Attr);//2.pthread_attr_init(pthread_attr_t *ptr)
	pthread_attr_getstacksize(&Attr, &Siz);//defualtstack size 8 m=mb..pth lib
	pthread_attr_getstackaddr(&Attr, &Stk);//def stack stackaddr before thd
	//pthread_attr_getstack(&Attr, &5tk,&Siz);
	
	printf("Default: Addr=%08%x default Size %ld\n", Stk, Siz);//p
																													//pthd lib sie to threads
	my_stack = (void*)malloc(my_stksize); // ptr = malloc(100);

	//ExplicitilySets Stack Address & Stack Size
	pthread_attr_setstack(&Attr, my_stack, my_stksize);
	
	pthread_create(&ID, &Attr, Proc, NULL); //thd stackaddr and thd stack size

	//Gts Stack Address & Stack Size
	pthread_attr_getstack(&Attr, &Stk, &Siz); //confirmation
	
	printf("Newly defined Stack : Addr=%08%x and Size= %ld\n",Stk,Siz);

	sleep(3);
	return (0);
}

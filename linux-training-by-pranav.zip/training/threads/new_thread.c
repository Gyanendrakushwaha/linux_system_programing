#include<stdio.h>
#include<pthread.h>
#include<unistd.h>

void *PrintHello(void *threadid)
{
	printf("\nHello World\n");
	printf("\nI am wating\n");
	while(1);
}

int main()
{
	pthread_t thread;
	int re,t=0;	
	printf("\nCreating thread %d\n",t);
	re = pthread_create(&thread,NULL,PrintHello,NULL);
	printf("\nThread ID: %u", thread);
																			//pthread_join(thread,NULL);
	sleep(6);
	t = pthread_cancel(thread);
	if(t==0)
	{
		printf("Cancel thread\n");
	}
	printf("\nThread ID: %d\n",thread);
}


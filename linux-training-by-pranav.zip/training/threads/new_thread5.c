#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
#include<bits/local_lim.h>

int main()
{
	pthread_attr_t tattr;
	pthread_t tid;
	int ret;
	void *stackbase;
	int size = PTHREAD_STACK_MIN + PTHREAD_STACK_MIN;
	size_t size1;
	stackbase = (void*) malloc(size);
	/* initiallized with default attribute */
	ret = pthread_attr_init(&tattr);
	ret = pthread_attr_getstacksize(&tattr,&size);
	printf("\n Default stack Size %u: ,",size);
	printf("\n Thread Minimum Stack Size %u :\n",PTHREAD_STACK_MIN);
	/* SETTING THE SIZE OF THE STACK ALSO */
	ret = pthread_attr_setstacksize(&tattr,size);
	ret = pthread_attr_getstacksize(&tattr,&size1);
	printf("\n User Stack Size %u :\n",size1);
}
	/* setting the base address in the attribute */	
	//ret = pthread_attr_setstackaddr(&tattr, stackbase);
	/* address and size specified */
	// ret = pthread_create(&tid, &tattr, fun, arg);


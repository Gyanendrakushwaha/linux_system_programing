#include <pthread.h>
#include<stdio.h>
pthread_t tid;

/*void printids(char *s)
{
	pid_t pid;
	pthread_t tid;
	printf("From main %u\n ",ntid);
	pid = getpid();
	tid = pthread_self();	
	printf("%s pid %u tid %u (0x%x)\n",s,(unsigned int)pid,(unsigned int)tid, (unsigned int)tid);
}*/

void *thr_fn(void *arg)
{
	//printids("new thread: ");
	//return((void *)0);
	

	pid_t pid;// process id
	pthread_t tid;// thrd_id
	pid = getpid();
	tid = pthread_self();//print calling thread id	
	printf(" pid %u tid %u \n",(unsigned int)pid,(unsigned int)tid);
	pthread_cancel(tid);
	return 0;

	
}

int main(void)
{
	int err;	
	err = pthread_create(&tid, NULL, thr_fn, NULL);
	if(err != 0)
		printf("can't create thread: %s\n", strerror(err));
	//printids("main thread: ");
	//sleep(3);
	while(1);		// $ps  -elf
	exit(0);
}

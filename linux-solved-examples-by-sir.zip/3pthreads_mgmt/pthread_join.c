#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<pthread.h>
pthread_t tid;// pthread_attr_t ===properties 
void* thread1(void *arg)
	{
	sleep(2);
	printf("Thread is executing\n");
	return NULL;
	}


int main(void){
	int ret = pthread_create(&tid, NULL, thread1, NULL);//posix
	//pthread_join(tid, NULL);
	if(ret)
		printf("Thread is not created\n");
	else
		printf("Thread is created\n");
	
	pthread_join(tid, NULL);//join thd with process main(process        execution)........makes main process to wait untill till thrd terminates
	printf("process terminating in 2 sec");		
	sleep(2);
	
	return 0;
}


	// pthread_create===success run thread func(no value return)
	
			//==== failure    EAGAIN = no enough resource
			//		EPERM  = no enough perms

	// pthread_join()   1.  join/sychn thd exectin with   process
			//   2.  makes main process to untill thd exectn is done


#include <pthread.h>
#include <stdio.h>
void *thr_fn1(void *arg)
{
	printf("thrd1 returning\n");
	printf("THD ID= %u\n",pthread_self());	
	//sleep(10);	
	return ((void*)1);
	//exit(1);
}

void *thr_fn2(void *arg)
{
	printf("thread 2 exiting\n");
	printf("THD ID= %u\n",pthread_self());
	//sleep(10);
	pthread_exit((void*)2);
}

int main(void)
{
	int err;
	pthread_t tid1,tid2;
	void *tret;
	
	pthread_create(&tid1, NULL, thr_fn1, NULL);
	
	pthread_create(&tid2, NULL, thr_fn2, NULL);
	
	pthread_join(tid1, &tret);
	printf("thread 1 exit code %d\n",(int)tret);
	
	pthread_join(tid2, &tret);
	
	//sleep(40);
	printf("thread 2 exit code %d\n", (int)tret);
	exit(0);
}














/*How do you find the return value of a pthread function?
If you want to return only status of the thread (say whether the thread completed what it intended to do) then just use pthread_exit or use a return statement to return the value from the thread function*/

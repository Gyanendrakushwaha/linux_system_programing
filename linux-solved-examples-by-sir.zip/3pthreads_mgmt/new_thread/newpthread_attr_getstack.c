#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/mman.h>
void* Proc(void* param)
{
        sleep(2);
        return 0;
}

int main( )
{
        pthread_attr_t Attr;//1
        pthread_t      Id;
        void          *Stk;
        size_t         Siz;//size_t   int
        int            err;

        size_t my_stksize = 3000000;
        void * my_stack;

        pthread_attr_init(&Attr);//2.pthread_attr_init(pthread_attr_t *ptr)

        pthread_attr_getstacksize(&Attr, &Siz);// default stack size 8mb..pthd lib
        pthread_attr_getstackaddr(&Attr, &Stk);// def stack stack addr before thd   							crtn   0000
	//pthread_attr_getstack(&Attr, &Stk, &Siz);

        printf("Default: Addr=%08x  default Size=%d\n", Stk, Siz);// p
							//pthd lib size to threads
      
	my_stack =(void*)malloc(my_stksize);	//   ptr = malloc(100);  //  mmap( );

        // Explicitily Sets Stack Address & Stack Size
	pthread_attr_setstack(&Attr, my_stack, my_stksize);

        pthread_create(&Id, &Attr, Proc, NULL);//thd stackaddr   and thd stack size

	// Gets Stack Address & Stack Size 
	pthread_attr_getstack(&Attr, &Stk,&Siz);//confirmation


        printf("newly defined Stack  : Addr=%08x  and Size=%d\n", Stk, Siz); 
	
	sleep(3);        
	
	return (0);


}





	/***read default atts
	pthread_attr_getstacksize(&Attr, &Siz);

 	pthread_attr_getstackaddr(&Attr, &Stk);/ / void *


 	definr my attr
	pthread_attr_setstack(&Attr, my_stack, my_stksize);**/

	
	











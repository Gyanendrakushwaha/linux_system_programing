#include<pthread.h>
#include<stdio.h>

pthread_once_t once = PTHREAD_ONCE_INIT;

void myinit() // executes only once fro first thread
{
	printf("\n I am in INIT FUNCTION\n");
}
void *mythread(void *i)
{
	printf("\n I am in mythread : %d\n",(int *)i);
	pthread_once(&once, myinit);
	//sleep(10);
	printf("\n Exit from mythread : %d\n",(int *)i);
}
int main()
{
	pthread_t thread1,thread2,thread3;
	pthread_create(&thread1,NULL,mythread,(void *)1);
	//sleep(2);
	pthread_create(&thread2,NULL,mythread,(void *)2);	
	//sleep(2);
	pthread_create(&thread3,NULL,mythread,(void *)3);	
	
	pthread_exit(NULL);
}
	
	
	
/*
The thread terminates explicitly by calling the pthread_exit function. If the main thread calls pthread_exit, 
it waits for all other peer threads to terminate and then terminates main thread
*/	

/*
pthread_once() is used in conjunction with a once control variable of the type pthread_once_t. 
This variable is a data type that you initialize to the PTHREAD_ONCE_INIT constant.
 It is then passed as a parameter on the pthread_once() function call. init_routine is a normal function.
*/
/*
nt pthread_once(pthread_once_t *once_control,
       void (*init_routine)(void));
pthread_once_t once_control = PTHREAD_ONCE_INIT; [Option End]

DESCRIPTION
The first call to pthread_once() by any thread in a process, with a given once_control, shall call the init_routine with no arguments. Subsequent calls of pthread_once() with the same once_control shall not call the init_routine. On return from pthread_once(), init_routine shall have completed. The once_control parameter shall determine whether the associated initialization routine has been called.

The pthread_once() function is not a cancellation point. However, if init_routine is a cancellation point and is canceled, the effect on once_control shall be as if pthread_once() was never called.

The constant PTHREAD_ONCE_INIT is defined in the <pthread.h> header.

The behavior of pthread_once() is undefined if once_control has automatic storage duration or is not initialized by PTHREAD_ONCE_INIT.

RETURN VALUE
Upon successful completion, pthread_once() shall return zero; otherwise, an error number shall be returned to indicate the error.

ERRORS
The pthread_once() function may fail if:

[EINVAL]
If either once_control or init_routine is invalid.
The pthread_once() function shall not return an error code of [EINTR].
*/

/*===> /etc/passwd is a text file that contains the attributes of (i.e., basic information about) each user or account on a computer running Linux  operating system.

The permissions for /etc/passwd are by default set so that it is word readable, that is, so that it can be read by any user on the system1. The file can be easily read using a text editor (such as gedit or vi) or with a command such as cat, which is commonly used to read files, i.e.,

cat /etc/passwd
*/

# include <sys/types.h>
# include <pthread.h>
# include <fcntl.h>
#include<unistd.h> 
#include<stdlib.h> 
#include<stdio.h> 


void * th_fn(void * p);

int fd;
int main()
{
    pthread_t t1,t2;

    fd = open("/etc/passwd",O_RDONLY);
    printf("File Opened with fd: %d \n",fd);//FD=3 returned kernel OS..fd=0,fd=1,fd=2
    pthread_create(&t1,NULL,th_fn,"Thread One");//fd=0 std i/p i.e KB//scanf
    pthread_create(&t2,NULL,th_fn,"Thread Two");//fd=1 std o/p i.e display screen//printf
    pthread_join(t1,NULL);			//fd=2  std error device	
    pthread_join(t2, NULL);	
}

void * th_fn(void * p)
{
    char * str, buff[100];
    int n, pid;
    str = (char *)p;
    pid = getpid();
    printf("%s: \t Started Now: \t For Process %d \n\n",str,pid);//thd one thd two
    do								//pid 
    {
        n = read(fd,buff,100);
        printf("%s: \t Read: \t %d \n\n",str,pid);
        printf("\n-------------------- \n");

	write(1,buff,n);			//fd=0 input i. keyboard
						// fd=1 output(display/screen) 							//fd=2  error device//fd=3
        printf("\n-------------------- \n");
        sleep(3);
    }while(n);
    printf("%s: \t Finished: \t For Process %d \n\n",str,pid);
}


//   sensor  /etc/passwd      thds              screen/display cloud  nw

// sensor  =======thds continous read emitted data can send to cloud  nw 							
// from /etc/passwd file alternat threads reading and writing to screen for evry 3 sec untill end of file reached

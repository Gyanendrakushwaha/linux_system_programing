#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<pthread.h>//posix----pthd lib---
			//impltns  crt  thd---
pthread_t tid;

//pthread_attr_t    my_attr;

void* thread1(void *arg){
	sleep(1);
	printf("newly created Thread is executing\n");
	return NULL;
}

int main(void)
{								//pthread_t *ptr
	int ret = pthread_create(&tid, NULL, thread1, NULL);	// addr of fucn...name of func
	if(ret)							//NULL default attr
		printf("Thread is not created\n");
	else
		printf("Thread is created\n");
		
								//sleep(2);//getchar();
	pthread_join( tid, NULL);
	return 0;
}

	//  process =====thread===process not waiting for thd exectin and complettion
	// process   crtd thd   ===process terminates even thread also terminates
	//since threads are same process addr space

	

	//process-----crt thd.....and process terminated w/o waiting thd to 		//complete its thd execution..



	//  PAS ========>  thd(own stack)
	


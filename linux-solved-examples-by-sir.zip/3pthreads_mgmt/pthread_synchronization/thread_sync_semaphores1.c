#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>
#include<semaphore.h>

int sharedVar=5;		// Our shared variable

sem_t my_sem;			// create Semaphore

void *thread_inc(void *arg){
	sem_wait(&my_sem);	// take semaphore
	for(i=0; i<100000 ;i++)
	sharedVar++;				// Critical Section
	sem_post(&my_sem);	// release semaphore
}

void *thread_dec(void *arg){

	sem_wait(&my_sem);	// take semaphore
			// take mutex
	for(i=0; i<100000 ; i++)
	sharedVar++;				// Critical Section
	sem_post(&my_sem);	// release semaphore

}




int main(){
	pthread_t thread1, thread2;
	
	sem_init(&my_sem, 0, 1);	// initialize semaphore

	pthread_create(&thread1, NULL, thread_inc, NULL);
	pthread_create(&thread2, NULL, thread_dec, NULL);

	pthread_join(thread1, NULL);
	pthread_join(thread2, NULL);

	printf("sharedVar = %d \n", sharedVar);
	return 0;
}

// int a;	
//int a=11;

//1 .declare semphore var
//		sem_t      mysem;

//2.initial the new ly semaphore...
//	
//	sem_init(sem_t  * ptr,)			open(char * pathname)
//
//	sem_init(&mysem,    0    ,1);			opne("one.txt")

//	sem_wait()
//	sem_poat()	

/* shows how to create multiple threads of control , Earlier we did this
using clone.
Version : 1.0
Author: Team -C.
*/

# include <pthread.h>
# include <unistd.h>
# include <stdio.h>

void * start_one(void *arg){
	int i;
	for(i=0;i<100;i++)
		printf(" Thd Of Control 1\n");
}

void * start_two(void *arg){
	int i;
	for(i=0;i<100;i++)
		printf("** Thd Of Control 2\n");
}

main(){
	pthread_t pt1,pt2;
	getchar();
	pthread_create(&pt1,NULL,start_one,NULL);	
	pthread_create(&pt2,NULL,start_two,NULL);	
	//getchar();	
	
	pthread_join(pt1, NULL);
	pthread_join(pt2, NULL);	
	printf("end of main thread \n");
}


// thds r more effectively employed on multiple core m/cs (dual/quad/octa) ....

// thd1 === cpu=0   thd2===cpu1 

#include <stdio.h>
#include <string.h>

int main () {
   const char str[] = "linuxkernel.com";
   const char ch = '#';
   //char *ret;
	
   printf("String before set/initialization  is %s  \n", str);

   memset(str, ch, 5);

   printf("String after set is %s  \n", str);

   return(0);
}

//#include <lclib.h>
#include<unistd.h>
#include <stdio.h>

int _mneed = 1024;       /* Define default size of sbrk area. */

main()
{
   int n;
   char *stg;

   for(n = 1; ; ++n){
      stg = sbrk(80);
      if (stg == (char *) -1) break;
   }
   printf("%d 80-byte blocks could be allocated by sbrk.\n", n);
   puts("To change the amount available to sbrk, pass "
          "the runtime option =/,");
   puts("replacing  with the size of the sbrk area.");
}

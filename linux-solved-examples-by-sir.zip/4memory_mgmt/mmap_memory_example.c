#include<stdio.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<sys/mman.h>

int main(){
	char *c;
	
	c = mmap(0, 50, PROT_READ|PROT_WRITE, MAP_ANONYMOUS|MAP_PRIVATE, -1, 0);//  msg  success
	perror("mmap");

	strcpy(c, "linuxkernel");//kernel region in U.S
	printf("%s\n", c);

	/* deallocate all resources */
	munmap(c, 50);// malloc      after free 
 	
	//printf("%s\n", c); 
	
	return 0;
}

/*mmap  .............. 1 addr arg   0....reqtng Kernel  plz map size of region (file/device/random)into free PAS
					recommended technique
					not providing own addr
		     	2 size
		      	3. flags that are protecting the mapped region(PAS)
		      	4.	MAP_PRIVATE.......this is not share with other process
		      	5.	fd/ -1
		      	6 file offset 0..	
			
			mmap() return addr of mapped region to ptr...	*/					

#include<stdio.h>
#include<unistd.h>

int main(void){
	printf("my session id=%d\n", getsid(0));//getsid() session id 
	//exit(0);	
	printf("my group id =%d\n", getpgid(0));//getpgid() group id inside we have processes
	printf("my process id =%d\n", getpid());//process id
	while(1);// ctrl + c  process terminates		
	return 0;
}



//pro pid -----group --alll pro
//	     gp id 
//	----session all gps
//i	-----sessiuion id

/* ch09-atexit.c --- demonstrate atexit().
Error checking omitted for brevity. */
/*
* The callback functions here just answer roll call.
* In a real application, they would do more.
*/

void callback1(void) 
{ 
	printf("callback1 func called\n"); 
}
void callback2(void) 
{ 
	printf("callback2  func called\n"); 
}
void callback3(void) 
{ 
	printf("callback3  func called\n"); 
}


/* main --- register functions and then exit */
int main( )
{
	printf("registering callback1\n");
	atexit(callback1);// atexit()
	printf("registering callback2\n"); 
	atexit(callback2);
	printf("registering callback3\n"); 
	atexit(callback3);
	printf("main()..exiting now\n");
	
exit(0);  //main  +   regtd func  trrmted

}




//case  when we have few func ..that we wanted to execute after the termnstion of //main func...then we register those funs with OS kernel ..using atexit(fun_name) system call.

//_exit(0);---funcs though regtd with OS , will get vanished.. removed ...they dont execute..



#include<stdio.h>
#include<unistd.h>

int main(void){
		
		printf("current process \n ");
		
		fork(); //exec once   return twice
			//  2 process child (new)  parent(orig)
			// new process new(child--pid) + current(parent--pid)
		
			//printf("LINUX Process11\n ");//2
		
		fork();//4
		fork();
		
		printf("LINUX Process22\n "); 
		printf("LINUX Process33\n ");
	
		  
		//fork();// 2 2 2 2===8
		
		
	while(1);//parent     wait state
		   //child    wait state
	return 0;
}		




	//   2 pow n   number   new process   n= times fork();


	//  fork();==2 diff
	// fork();=====4 diff processes
	//	fork();== 8  diff

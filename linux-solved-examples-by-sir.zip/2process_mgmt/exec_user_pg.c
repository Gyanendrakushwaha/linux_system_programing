#include<stdio.h>
#include<unistd.h>

int main()
{
	//int ret;	
	printf("I am going to exec an user program\n");
	execl("/home/user/Documents/GUNI/Linux_Programming/Process/vfork","./vfork" ,0);//./1, ./1,//usr 								defined
	
	printf("i executed new program \n");
	printf("i executed new program \n");
	printf("i executed new program \n");
}

#include<stdio.h>
#include<unistd.h>

int main(void){
	pid_t pid;
	printf("current process pid =%d\n", getpid());
	
	pid = vfork();	// parent suspended
	
	if(pid){
								//sleep(1);
		printf("parent process pid = %d\n", getpid());//if designed 										critical real time     optn
	}
	else{

	sleep(5);		
	printf("child process pid =%d\n", getpid());//parent pro suspended by  									vfork() call
							//block optn
	}
	exit(0);
	return 0;
}

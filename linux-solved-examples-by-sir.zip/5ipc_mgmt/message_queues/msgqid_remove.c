/* example showing how to create msgq.
Version : 1.0
Author : Team -C
*/

# include <stdio.h>
# include <unistd.h>
# include <sys/types.h>
# include <sys/ipc.h>
# include <sys/msg.h>

# define KEY 88

main(){
	int qid;
	qid = msgget(KEY,IPC_CREAT|644);
	printf(" qid = %d\n", qid);
	getchar();
	msgctl(qid,IPC_RMID,NULL);
}//write a program that creates message queue and display msgq id and remove the allocated message queue from system. 

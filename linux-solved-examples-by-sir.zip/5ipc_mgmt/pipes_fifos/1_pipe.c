#include<stdio.h>
#include<unistd.h>
#include<string.h>
int main()
{
	int p[2];// p[0],p[1]  indexex or subscripts of array p

	pipe(p);//fd0 --P[0]rd end   and   fd1---P[1] wt end
	printf("Read end of pipe = %d \t Write end of pipe = %d\n", p[0], p[1]);//  3,    4
	if(fork())
	{	//Parent..
		char s[20];
		printf("In Parent Enter Data...\n");
		scanf("%s", s);//wait user  enter "15 +1"
		write(p[1], s, strlen(s)+1);	//Parent send data on pipe....write(fd, buf , 20);
	}
	else {		//Child--0
		char buf[20];
		printf("In child...\n");
		read(p[0], buf, sizeof(buf));	//block.....	Child collect data
		printf("child pro printing..Data. of the parent process..%s\n",buf);
	}

	return 0;
}



// 1.pipe used bw parent and child proceses ....fork();

//write()  read()...............std file operations 
//why calling wr()  n rd() on pipes.............pipes are also internally..thew are(pipes )
//special files which have 2 FDs...fd[0] fd[1].....
//


//parent process wrting data  fd[1]==============fd[o]  child read 
//		                   ==============      





//2.capacity/size of ur pipe limited 

	



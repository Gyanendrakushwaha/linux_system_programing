
/* using sigset_t.

*/

# include <stdio.h>
# include <signal.h>


main(){
	int  i, res;
	sigset_t s_set,o_set;
	sigemptyset(&s_set);
	sigaddset(&s_set,1);
	sigaddset(&s_set,4);
	sigprocmask(SIG_BLOCK|SIG_SETMASK,&s_set,&o_set);
	for(i =1;i<5;i++){
		res = sigismember(&o_set,i);
		if(res)
			printf(" signal %d is blocked \n",i);
		else
			printf(" signal %d is not blocked \n",i);
	}
	
	
	for(i =1;i<5;i++){
		res = sigismember(&s_set,i);
		if(res)
			printf(" signal %d is blocked \n",i);
		else
			printf(" signal %d is not blocked \n",i);
	}
	//check_blocked_sigs();
}

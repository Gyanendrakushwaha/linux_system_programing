/*Sample program that show the handling of a SIGINT (Control-C) signal.*/
#include <stdio.h>
#include <signal.h>

void mysighandler(int signo)
{
	printf("i Caught the signal %d\n",signo);
}

int main()
{
	//signal(SIGINT,mysighandler);
	while(1)
	{
		sleep(15);
		printf("I slept for 15 seconds\n");
	}
}



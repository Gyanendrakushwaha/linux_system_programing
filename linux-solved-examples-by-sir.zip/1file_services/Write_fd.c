#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>

int main(){
	int fd, len;
	int x;
	
	char write_buf[60]="Linux kernel new program ?, wow?";
	
	
	fd = open("linuxabc.txt",O_CREAT  |  O_RDWR, 0777);//creation---open---fd file,open,fd***==open(O_CREAT) == creat()

	write(fd, write_buf,60);//from write_buf wting to fd(linux_xyz.txt)
	
	//printf("return value =%d\n", len);
	
	close(fd);
	return 0;
}

	//open()/creat()/write()/close()
	

	//     int  write(int fd,	void* buf,	int size);
	//   		write(fd,write_buf,60)

	//    write() return no bytes writtn to file
	

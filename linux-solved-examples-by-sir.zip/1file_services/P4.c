#include<stdio.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<unistd.h>

int main(){
	int fd;
	char buf[300];// buf empty buffer loctn//memory
	int res;
	fd = open("maxfds.c", O_CREAT|O_RDWR, 777);
	printf("%d\n", fd);//3 
	if(fd<0)
		printf("File is not opened or created\n");	
	read(fd,buf,300);///   from  fd (dup1.c file) to empty buf) 
	//printf("return value of read()=%d\n", res);
	printf("data from buffer = %s\n", buf);
	close(fd);

	return 0;
}

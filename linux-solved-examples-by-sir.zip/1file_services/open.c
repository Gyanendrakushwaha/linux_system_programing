#include<stdio.h>
#include<fcntl.h>

int main(){

	int fd1, fd2 ,fd3;
	
	
	fd2 = open("linux111.txt",  O_WRONLY , 777);
	fd1 = open("create.c",  O_WRONLY , 777);

	//fd3 = open("linux_xyz.txt", O_WRONLY, 777);  // OPEN() API// SYSTEM CALLS
	

	printf("fd returned by kernel for linux111.txt =%d\n", fd2);//3
	
	printf("fd returned by kernel for create.c =%d\n", fd1);   //4
		// 0 , 1 ,2 used by kernel/least available FDs linux OS ... 3 4 5..	1023 
	close(fd2);
	close(fd1);
	
}	
		// 1024  files 
		//
		//How many files a linux process(running program) can open	...1024 files
		




	//fd = 0  std input device KB device file
	//fd =1 std outpur display/console device file
	//fd =2 std error device


	//Q.how many files a program can open?==> 1024 files (fd table)

	// fd   0   to 1023


	

	

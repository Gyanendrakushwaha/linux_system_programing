#include <stdio.h>
#include <unistd.h>

int main()
{
	printf("max fds: %d\n",getdtablesize());//  will get fd table size 
	exit(0);
}

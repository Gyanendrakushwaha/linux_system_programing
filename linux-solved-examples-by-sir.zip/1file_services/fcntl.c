#include<stdio.h>
#include<fcntl.h>

int main(){
	int fd1,fd2,fd3;

	fd1 = open("linux.txt", O_WRONLY|O_CREAT|O_TRUNC, 0777);//3
	
	fd3 = fcntl(fd1, F_DUPFD,55);//dup2()

	printf("duplicate value of fd1 is fd3 = %d\n",fd3);
			
	close(fd1);
	close(fd3);
	}

	//dup/dup2/fcntl

	//fcntl(int fd, int cmd,....)

	//F_DUPFd		fd

	//F_GETFL/F_SETFL	flags
	//F_GETOWN/F_SETOWN	own
	//F_GETLK/F_SETLK	record lock





	  
	//success cmd used		-1
	//fd, ownership,record lock,flags
	//   F_DUPFD      
	//	F_GETFL/F_SETFL
	//	F_GETOWN/F_SETOWN
	//	F_GETLK/F_SETLk






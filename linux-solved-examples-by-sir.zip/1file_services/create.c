#include<stdio.h>
#include<fcntl.h>

int main(){
	int fd1, fd2, fd3;

	fd1=creat("linux100.txt",0777); //3 // creating files , which are already 	exisiting kernel retun failure...  -1    
	  //creat(char * path,modes)	
	   
	fd2=creat("linux200.txt", 0777);//4

	fd3=creat("linux300.txt",0777);//5......0,1,2   OS kernel for our pg

	printf("fd for Linux100.txt=%d\n",fd1);
	printf("fd for Linux200.txt=%d\n",fd2);
	printf("fd for Linux300.txt=%d\n",fd3);	
	
	close(fd1);// what ever resources that we take OS kernel, we need to give back to kernel after job done
	close(fd2);
	close(fd3);

	return 0;
}


	//        int  creat("char * pathname", mode_t modes);
	//          3   files  crtd n opened 
	//Q.   from a pg(process) how many file caan we crt n open/..................1024  crt/open  (0-1023  range of fds)  
	//  3 files    3    4    5     6   7    8   9  ...........1023 fd   (0  1   2  fds are used OS)
	//one.c   5    files    3 4 5 6 7......two.c    3    files    3 4 5 .......1023        three.c   10  files    3 4 5 ......12

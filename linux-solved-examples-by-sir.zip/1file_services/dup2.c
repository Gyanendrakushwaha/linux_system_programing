#include<stdio.h>
#include<fcntl.h>

int main(){
	int fp1,fp2,fp3;
	//int fd3=15;
//	umask(0);
	
	char buf[200];
	
	fp1=open("linux.txt", O_WRONLY|O_CREAT|O_TRUNC, 0777);//3
	
	fp2=open("P22.c", O_WRONLY|O_CREAT|O_TRUNC, 0777);//4
	
	printf("FD of FP1=%d\n", fp1);//3
	
	printf("FD of FP2=%d\n", fp2);//4
	
	fp3 = dup2(fp1, 4 );//generating descriptor our own reqd value.... 44

	printf("fp3 is our defined dup of FP1=%d\n", fp3);//10
							  //
		
	close(fp1);
	close(fp2);
	close(fp3);
	}

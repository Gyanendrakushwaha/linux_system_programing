#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>

int main(){
	int fd, len;
	char write_buf[50]="hi, how are you1?, wow?";
	char read_buf[50];
	
	fd = open("linux_kernel.txt",O_CREAT|O_RDWR, 777);//CFO
	
	len = write(fd, write_buf,50);//50 return, curr file off mved 50th loctn

	printf("return value from write optn =%d\n", len);// 50
				//close(fd1);

	
				//lseek(fd,4,SEEK_SET);//rewind current file offset to (0 loctn)start point in file "linux_kernel.txt"
	
				//fd2 = open("5s10.txt",O_CREAT|O_RDWR,0777);
	
	read(fd,read_buf,len);

	printf("data from from buffer(read optn) = %s\n", read_buf);// garbage
				//printf("%d\n", len);

	close(fd);	

	return 0;
}
	//creat..open...write...read...close.....
	//wrbuf---->linux_ker1.txt------>rdbuf----->display--->close




	/****
	
	off_t lseek(int fd, off_t offset_value,int whence);

		lseek(fd,	10,	);

	1. lseek() used for repositioning of current file offset. {   rewind...forward   }   
	2. Interpretation of lseek() optn purely  depend whence arg

	int whence

	SEEK_SET	lseek(fd,10,SEEK_SET);from begining of the file 10 location + 		offsetvalue....0.....to this location changing file_offset....
	SEEK_CUR	lseek(fd,20,SEEK_CUR);from current locn 100 - 20	===80 offset	
	SEEK_END		changing file offset from end /EOF end of file +/- offet value
	******/

	//read();
	//wrte();
	//write and read.....issue
	//lseek()....read...success


	//   abc.txt
	//	k*dkjddlkl*(10)dkkkl;		lseek(fd  , 0  , SEEK_SET)
	//	ldk;sldlsdsdslds'		lseek(fd, 40, SEEK_CUR)		
	//	dll;sl;sld;s'd;s';d(100)	lseek(fd, -90, SEEK_END)





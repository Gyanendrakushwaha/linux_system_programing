#include<stdio.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>

int main(){
	int fd;
	char buf[300];

	fd = open("dup2.c", O_RDWR, 0777);

	printf("FD value =%d\n",fd);
	if(fd<0)
		printf("File is not opened/created\n");	

	read(fd,buf,300);

	printf("%s\n", buf); 

	close(fd);
	
	return 0;
}
